"""
fixtures/scoring_helpers.py

Minimal re-implementations of the scoring path for Detect-Person and
Detect-Vehicle ONLY. No PlayerDetect, no smoothness, no iou/count pillars.

These mirror the exact code in:
  scorevision/utils/evaluate.py              (parse_miner_prediction)
  scorevision/vlm_pipeline/non_vlm_scoring/objects.py  (_build_per_image_rows,
                                              _evaluate_detection_metrics_at_threshold,
                                              _evaluate_detection_metrics)
  scorevision/utils/manifest.py              (weight_score)

Any divergence from those functions is a bug in this file, not a test finding.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional
import math


# ── Manifest values (live, block 7819505) ────────────────────────────────────
ELEMENTS = {
    "manak0/Detect-Person": {
        "objects": ["person"],
        "w_map50": 0.65,
        "w_fp": 0.35,
        "baseline_theta": 0.3755112726134544,
        "delta_floor": 0.01,
        "beta": 1.0,
        "service_rate_fps": 5,
        "latency_p95_ms_budget": 10000,
        "max_model_mb": 30,
        "n_images": 30,
    },
    "manak0/Detect-detect-vehicle": {
        "objects": ["vehicle"],   # confirm against live manifest
        "w_map50": 0.60,
        "w_fp": 0.40,
        "baseline_theta": 0.40716123737774484,
        "delta_floor": 0.01,
        "beta": 1.0,
        "service_rate_fps": 5,
        "latency_p95_ms_budget": 10000,
        "max_model_mb": 30,
        "n_images": 30,
    },
}


# ── Data structures mirroring the validator ──────────────────────────────────
@dataclass
class Box:
    x1: int
    y1: int
    x2: int
    y2: int
    cls_id: int
    conf: float  # must be present and in [0,1]


@dataclass
class PredFrame:
    frame_id: int
    boxes: List[Box]


@dataclass
class GTBox:
    x1: int
    y1: int
    x2: int
    y2: int
    label: str  # already the string from element.objects


@dataclass
class GTFrame:
    frame_number: int
    boxes: List[GTBox]


# ── Exact replica of _normalize_class_name (objects.py line 47) ──────────────
def normalize_class_name(label: object) -> str:
    if label is None:
        return ""
    return str(label).strip().lower()


# ── Exact replica of _iou_box (objects.py lines 29-44) ───────────────────────
def iou_box(a, b) -> float:
    xa1, ya1, xa2, ya2 = a
    xb1, yb1, xb2, yb2 = b
    inter_x1, inter_y1 = max(xa1, xb1), max(ya1, yb1)
    inter_x2, inter_y2 = min(xa2, xb2), min(ya2, yb2)
    iw = max(0, inter_x2 - inter_x1)
    ih = max(0, inter_y2 - inter_y1)
    inter = iw * ih
    if inter == 0:
        return 0.0
    area_a = max(0, xa2 - xa1) * max(0, ya2 - ya1)
    area_b = max(0, xb2 - xb1) * max(0, yb2 - yb1)
    union = area_a + area_b - inter
    return inter / union if union > 0 else 0.0


# ── Exact replica of _average_precision (objects.py lines 66-78) ─────────────
def average_precision(recalls: List[float], precisions: List[float]) -> float:
    if not recalls or not precisions or len(recalls) != len(precisions):
        return 0.0
    mrec = [0.0] + [float(v) for v in recalls] + [1.0]
    mpre = [0.0] + [float(v) for v in precisions] + [0.0]
    for idx in range(len(mpre) - 2, -1, -1):
        mpre[idx] = max(mpre[idx], mpre[idx + 1])
    area = 0.0
    for idx in range(len(mrec) - 1):
        delta = mrec[idx + 1] - mrec[idx]
        if delta > 0:
            area += delta * mpre[idx + 1]
    return float(area)


# ── parse_miner_prediction replica (evaluate.py lines 88-144) ────────────────
def parse_miner_prediction(pred_frames: List[PredFrame],
                            object_names: List[str]) -> dict:
    """
    Mirrors evaluate.py parse_miner_prediction().
    Returns dict[frame_number -> list[parsed_box_dicts]]
    where each box dict has: class (str), bbox (list[4]), score (float)
    """
    result = {}
    for frame in pred_frames:
        parsed_boxes = []
        for box in frame.boxes:
            try:
                object_id = int(box.cls_id)
            except (TypeError, ValueError):
                continue  # silently dropped
            if not (0 <= object_id < len(object_names)):
                continue  # silently dropped -- THIS IS THE CRITICAL CHECK
            label = object_names[object_id]
            parsed_boxes.append({
                "class": normalize_class_name(label),
                "bbox": [box.x1, box.y1, box.x2, box.y2],
                "score": float(box.conf),
            })
        result[frame.frame_id] = parsed_boxes
    return result


# ── _build_per_image_rows replica (objects.py lines 87-124) ──────────────────
def build_per_image_rows(gt_frames: List[GTFrame],
                          parsed_predictions: dict) -> List[dict]:
    """
    Joins GT frames with miner predictions by frame_number.
    Missing frame_number in predictions -> empty predictions for that frame.
    """
    rows = []
    for gt_frame in gt_frames:
        fn = gt_frame.frame_number
        pred_boxes = parsed_predictions.get(fn, [])

        gt_detections = []
        for box in gt_frame.boxes:
            cn = normalize_class_name(box.label)
            if not cn:
                continue
            gt_detections.append({
                "class": cn,
                "bbox": [box.x1, box.y1, box.x2, box.y2],
            })

        rows.append({
            "image_id": str(fn),
            "gt": gt_detections,
            "predictions": pred_boxes,
        })
    return rows


# ── _evaluate_detection_metrics_at_threshold replica (objects.py 127-248) ────
def evaluate_at_threshold(per_image: List[dict],
                           iou_threshold: float = 0.5) -> dict:
    """
    Exact replica. Returns map50, ffpi, precision, recall.
    """
    gt_by_class_image: dict = {}
    pred_by_class: dict = {}
    class_names: set = set()

    for row in per_image:
        image_id = str(row.get("image_id", ""))
        for det in row.get("gt") or []:
            cn = normalize_class_name(det.get("class"))
            bbox = det.get("bbox")
            if not cn or not isinstance(bbox, list) or len(bbox) != 4:
                continue
            class_names.add(cn)
            gt_by_class_image.setdefault(cn, {}).setdefault(
                image_id, []).append([float(v) for v in bbox])

        for det in row.get("predictions") or []:
            cn = normalize_class_name(det.get("class"))
            bbox = det.get("bbox")
            if not cn or not isinstance(bbox, list) or len(bbox) != 4:
                continue
            class_names.add(cn)
            pred_by_class.setdefault(cn, []).append(
                (float(det.get("score", 1.0)), image_id,
                 [float(v) for v in bbox]))

    map_candidates = []
    global_tp = 0
    global_fp = 0
    global_gt = 0

    for cn in sorted(class_names):
        gt_images = gt_by_class_image.get(cn, {})
        n_gt = sum(len(v) for v in gt_images.values())
        preds = sorted(pred_by_class.get(cn, []),
                       key=lambda r: r[0], reverse=True)

        matched = {img_id: [False] * len(boxes)
                   for img_id, boxes in gt_images.items()}
        tp_flags, fp_flags = [], []

        for score, image_id, pred_bbox in preds:
            gt_boxes = gt_images.get(image_id, [])
            best_idx, best_iou = -1, 0.0
            for gt_idx, gt_bbox in enumerate(gt_boxes):
                if matched.get(image_id, [])[gt_idx] if image_id in matched else False:
                    continue
                iou = iou_box(pred_bbox, gt_bbox)
                if iou > best_iou:
                    best_iou = iou
                    best_idx = gt_idx
            if best_idx >= 0 and best_iou >= iou_threshold:
                if image_id in matched:
                    matched[image_id][best_idx] = True
                tp_flags.append(1)
                fp_flags.append(0)
            else:
                tp_flags.append(0)
                fp_flags.append(1)

        global_tp += sum(tp_flags)
        global_fp += sum(fp_flags)
        global_gt += n_gt

        if n_gt > 0:
            cum_tp, cum_fp = 0, 0
            recalls, precisions = [], []
            for tp, fp in zip(tp_flags, fp_flags):
                cum_tp += tp
                cum_fp += fp
                recalls.append(cum_tp / n_gt)
                denom = cum_tp + cum_fp
                precisions.append(cum_tp / denom if denom > 0 else 0.0)
            ap = average_precision(recalls, precisions)
            map_candidates.append(ap)

    n_images = len(per_image)
    ffpi = global_fp / n_images if n_images > 0 else 0.0
    precision = global_tp / (global_tp + global_fp) if (global_tp + global_fp) > 0 else 0.0
    recall = global_tp / global_gt if global_gt > 0 else 0.0

    return {
        "map50": float(sum(map_candidates) / len(map_candidates)) if map_candidates else 0.0,
        "ffpi": float(ffpi),
        "fp_score": max(0.0, 1.0 - ffpi / 10.0),
        "precision": float(precision),
        "recall": float(recall),
        "global_tp": global_tp,
        "global_fp": global_fp,
    }


# ── weight_score replica (manifest.py lines 344-358) ─────────────────────────
def weight_score(map50: float, fp_score: float, element_id: str) -> dict:
    """
    Exact replica of Element.weight_score().
    Returns breakdown dict with total_weighted, improvement, gated.
    """
    cfg = ELEMENTS[element_id]
    total_weighted = map50 * cfg["w_map50"] + fp_score * cfg["w_fp"]
    improvement = max(
        max(total_weighted - cfg["baseline_theta"], 0.0),
        cfg["delta_floor"]
    )
    gated = cfg["beta"] * improvement
    return {
        "total_weighted": total_weighted,
        "improvement": improvement,
        "gated": gated,
        "above_theta": total_weighted > cfg["baseline_theta"],
    }


# ── RTF formula (rtf.py lines 11-28) ─────────────────────────────────────────
def calculate_rtf(p95_latency_ms: float, service_rate_fps: float = 5) -> float:
    """Exact replica of calculate_rtf()."""
    return (p95_latency_ms / 10000.0) * (service_rate_fps / 5.0)


def rtf_passes(p95_latency_ms: float, service_rate_fps: float = 5) -> bool:
    return calculate_rtf(p95_latency_ms, service_rate_fps) <= 1.0


# ── Synthetic test data factories ─────────────────────────────────────────────
def make_gt_frame(frame_number: int, n_objects: int = 3,
                  label: str = "person",
                  image_size: int = 640) -> GTFrame:
    """Create a synthetic GT frame with n non-overlapping boxes."""
    boxes = []
    step = image_size // (n_objects + 1)
    for i in range(n_objects):
        x = step * (i + 1)
        y = step * (i + 1)
        boxes.append(GTBox(x1=x-30, y1=y-60, x2=x+30, y2=y+60, label=label))
    return GTFrame(frame_number=frame_number, boxes=boxes)


def make_pred_frame(frame_id: int, gt_frame: GTFrame,
                    cls_id: int = 0,
                    iou_quality: float = 0.8,
                    n_extra_fp: int = 0,
                    conf: float = 0.9) -> PredFrame:
    """
    Create a pred frame that matches GT boxes with given IoU quality,
    plus n_extra_fp spurious detections.
    iou_quality controls how well boxes match GT (1.0 = perfect).
    """
    boxes = []
    for gt_box in gt_frame.boxes:
        w = gt_box.x2 - gt_box.x1
        h = gt_box.y2 - gt_box.y1
        # shrink/shift proportional to (1 - iou_quality)
        delta = int(w * (1 - iou_quality) * 0.5)
        boxes.append(Box(
            x1=gt_box.x1 + delta,
            y1=gt_box.y1 + delta,
            x2=gt_box.x2 - delta,
            y2=gt_box.y2 - delta,
            cls_id=cls_id,
            conf=conf,
        ))
    # add false positives in corners
    for i in range(n_extra_fp):
        x = 10 + i * 50
        boxes.append(Box(x1=x, y1=5, x2=x+40, y2=55, cls_id=cls_id, conf=0.3))
    return PredFrame(frame_id=frame_id, boxes=boxes)


def score_full_pipeline(gt_frames: List[GTFrame],
                         pred_frames: List[PredFrame],
                         element_id: str) -> dict:
    """
    Run the full scoring pipeline for a Detect element.
    Returns all intermediate values plus final gated score.
    """
    cfg = ELEMENTS[element_id]
    parsed = parse_miner_prediction(pred_frames, cfg["objects"])
    rows = build_per_image_rows(gt_frames, parsed)
    metrics = evaluate_at_threshold(rows, iou_threshold=0.5)
    gating = weight_score(metrics["map50"], metrics["fp_score"], element_id)
    return {**metrics, **gating}
