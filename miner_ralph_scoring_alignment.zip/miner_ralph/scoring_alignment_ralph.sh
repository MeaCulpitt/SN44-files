#!/bin/bash
# scoring_alignment_ralph.sh
#
# Ralph loop for SN44 miner scoring alignment.
# Runs Claude Code iteratively against plan.md and progress.txt.
# Each iteration works on ONE alignment check from the plan.
#
# Usage:
#   ./scoring_alignment_ralph.sh              # run until COMPLETE or error
#   ./scoring_alignment_ralph.sh 5            # run at most 5 iterations
#   ./scoring_alignment_ralph.sh 1            # single iteration (debug)
#
# Prerequisites:
#   - Claude Code installed (claude command available)
#   - turbovision repo cloned at ../turbovision (or update SCORING_REPO below)
#   - Your miner code at ../miner (or update MINER_REPO below)
#   - Python 3.10+ in PATH
#
# Directory layout expected:
#   ./plan.md                   -- this file defines all checks (read-only by agent)
#   ./progress.txt              -- append-only session log
#   ./fixtures/scoring_helpers.py -- scoring path replicas
#   ./tests/                    -- test files
#   ../turbovision/             -- the validator scoring source (read-only)
#   ../miner/                   -- your miner code (agent may modify)

set -e

MAX_ITER=${1:-20}
SCORING_REPO="../turbovision"
MINER_REPO="../miner"

# Verify required paths exist
if [ ! -f "plan.md" ]; then
  echo "ERROR: plan.md not found. Run from the miner_ralph/ directory."
  exit 1
fi
if [ ! -f "progress.txt" ]; then
  echo "ERROR: progress.txt not found."
  exit 1
fi
if [ ! -d "$SCORING_REPO" ]; then
  echo "ERROR: Scoring repo not found at $SCORING_REPO"
  echo "Clone turbovision or update SCORING_REPO in this script."
  exit 1
fi

echo "Starting scoring alignment Ralph loop (max $MAX_ITER iterations)"
echo "Scoring repo: $SCORING_REPO"
echo "Miner repo:   $MINER_REPO"
echo ""

for ((i=1; i<=$MAX_ITER; i++)); do
  echo "=== Iteration $i / $MAX_ITER ==="

  result=$(claude -p \
    "@plan.md \
     @progress.txt \
     @fixtures/scoring_helpers.py \
     @$SCORING_REPO/scorevision/utils/evaluate.py \
     @$SCORING_REPO/scorevision/vlm_pipeline/non_vlm_scoring/objects.py \
     @$SCORING_REPO/scorevision/utils/rtf.py \
     @$SCORING_REPO/scorevision/utils/manifest.py \
     @$MINER_REPO/miner.py \

You are verifying that a Bittensor SN44 miner's output is correctly
aligned with the validator's scoring functions for Detect-Person and
Detect-Vehicle ONLY.

SCOPE: Only map50 and false_positive pillars are active for these elements.
Do NOT work on smoothness, iou, count, precision, recall, or keypoints.

SEQUENCE FOR THIS ITERATION:

1. Read progress.txt. Identify the first check whose status is TODO or FAIL.
   If all checks show PASS, output <promise>COMPLETE</promise> and stop.

2. Read the check definition from plan.md for that check number.

3. Look at the relevant scoring function in the provided source files.
   Understand EXACTLY what it does -- do not assume, read the code.

4. Run the corresponding test file:
   tests/test_class_mapping.py          -- CHECK 1
   tests/test_frame_alignment.py        -- CHECK 2
   tests/test_confidence_and_gate.py    -- CHECK 3 + 5 + 6
   tests/test_box_validity_and_rtf.py   -- CHECK 4 + 7 + 8

   Run it with: python tests/test_<name>.py
   Capture stdout and stderr.

5. If ALL tests in the file pass:
   Append to progress.txt: [CHECK N] PASS -- <one line summary>
   Move on.

6. If any test fails:
   a. Read the failure message carefully.
   b. Identify whether the fix is in miner.py or in the test itself
      (test bugs are possible -- cross-check against the scoring source).
   c. If the fix is in miner.py: implement it, re-run the test, verify PASS.
   d. Append to progress.txt:
        [CHECK N] FIXED -- <what was wrong and what was changed>
   e. Make an atomic git commit: git commit with the test file and miner.py

7. If you cannot determine the fix:
   Append to progress.txt: [CHECK N] BLOCKED -- <exact failure + what you tried>
   Move to the next TODO check.

CONSTRAINTS:
- ONLY work on ONE check per iteration.
- Do NOT modify the scoring source files (evaluate.py, objects.py, etc).
- Do NOT add smoothness, iou, count, precision, recall tests -- not relevant.
- Do NOT deploy to Chutes in this loop -- this is code analysis only.
- The scoring source files are GROUND TRUTH. Your miner must match them.
- If a test assertion seems wrong, verify against the source before changing it.
")

  echo "$result"
  echo ""

  # Run the tests once more to confirm state
  echo "--- Verifying test state ---"
  python tests/test_class_mapping.py 2>&1 | tail -3
  python tests/test_frame_alignment.py 2>&1 | tail -3
  python tests/test_confidence_and_gate.py 2>&1 | tail -3
  python tests/test_box_validity_and_rtf.py 2>&1 | tail -3
  echo ""

  if [[ "$result" == *"<promise>COMPLETE</promise>"* ]]; then
    echo "All alignment checks verified and passing."
    echo "Your miner output is correctly aligned with the scoring functions."
    echo ""
    echo "Next step: deploy to Chutes and monitor shard log for"
    echo "  per-pillar scores matching your local predictions."
    exit 0
  fi

done

echo "Reached max iterations ($MAX_ITER). Check progress.txt for status."
exit 0
