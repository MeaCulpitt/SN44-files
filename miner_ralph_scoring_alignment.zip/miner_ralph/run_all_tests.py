#!/usr/bin/env python3
"""
run_all_tests.py

Master test runner for SN44 scoring alignment checks.
Runs all test files, reports per-check status, updates progress.txt.

Usage:
    python run_all_tests.py              # run all checks
    python run_all_tests.py --check 1   # run only CHECK 1
    python run_all_tests.py --verbose   # show all test output
    python run_all_tests.py --update-progress  # append results to progress.txt
"""
import sys
import os
import subprocess
import argparse
from datetime import datetime

# Map check numbers to test files and descriptions
CHECKS = {
    1: {
        "file": "tests/test_class_mapping.py",
        "description": "Class mapping -- cls_id -> element.objects string",
        "priority": "CRITICAL",
    },
    2: {
        "file": "tests/test_frame_alignment.py",
        "description": "Frame number alignment -- frame_id matches GT frame_numbers",
        "priority": "CRITICAL",
    },
    3: {
        "file": "tests/test_confidence_and_gate.py",
        "description": "Confidence scores + FP budget + gate computation",
        "priority": "HIGH",
    },
    4: {
        "file": "tests/test_box_validity_and_rtf.py",
        "description": "Box coordinate validity + class normalisation + RTF gate",
        "priority": "HIGH",
    },
    5: {
        "file": "tests/test_copy_miner_differentiation.py",
        "description": "Copy-miner differentiation -- per-challenge score separation",
        "priority": "MEDIUM",
    },
}


def run_test_file(filepath: str, verbose: bool = False) -> tuple[bool, str, int, int]:
    """
    Run a test file, return (passed, output, n_passed, n_failed).
    """
    result = subprocess.run(
        [sys.executable, filepath],
        capture_output=True,
        text=True,
        cwd=os.path.dirname(os.path.abspath(__file__)),
    )
    output = result.stdout + (result.stderr if result.stderr else "")
    passed = result.returncode == 0

    # Count pass/fail
    n_passed = output.count("  PASS  ")
    n_failed = output.count("  FAIL  ") + output.count("  ERROR ")

    return passed, output, n_passed, n_failed


def parse_progress(filepath: str) -> dict:
    """Read current check statuses from progress.txt."""
    statuses = {}
    if not os.path.exists(filepath):
        return statuses
    for line in open(filepath):
        line = line.strip()
        for check_num in CHECKS:
            prefix = f"[CHECK {check_num}]"
            if line.startswith(prefix):
                rest = line[len(prefix):].strip()
                for status in ["PASS", "FAIL", "FIXED", "BLOCKED", "IN_PROGRESS"]:
                    if rest.startswith(status):
                        statuses[check_num] = status
                        break
    return statuses


def append_progress(filepath: str, lines: list[str]) -> None:
    """Append lines to progress.txt."""
    with open(filepath, "a") as f:
        f.write("\n")
        for line in lines:
            f.write(line + "\n")


def main():
    parser = argparse.ArgumentParser(description="SN44 scoring alignment test runner")
    parser.add_argument("--check", type=int, choices=list(CHECKS.keys()),
                        help="Run only this check number")
    parser.add_argument("--verbose", action="store_true",
                        help="Show full test output")
    parser.add_argument("--update-progress", action="store_true",
                        help="Append results to progress.txt")
    args = parser.parse_args()

    checks_to_run = {args.check: CHECKS[args.check]} if args.check else CHECKS
    progress_file = "progress.txt"
    current_statuses = parse_progress(progress_file)

    print("=" * 70)
    print("SN44 Scoring Alignment Check Runner")
    print(f"Elements: manak0/Detect-Person, manak0/Detect-detect-vehicle")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 70)
    print()

    results = {}
    total_passed = 0
    total_failed = 0

    for check_num, check_info in checks_to_run.items():
        filepath = check_info["file"]
        desc = check_info["description"]
        priority = check_info["priority"]
        prior_status = current_statuses.get(check_num, "TODO")

        print(f"CHECK {check_num} [{priority}]: {desc}")
        print(f"  File: {filepath}")
        if prior_status != "TODO":
            print(f"  Prior status: {prior_status}")

        if not os.path.exists(filepath):
            print(f"  SKIP -- test file not found")
            results[check_num] = ("SKIP", "", 0, 0)
            continue

        ok, output, n_pass, n_fail = run_test_file(filepath, args.verbose)
        total_passed += n_pass
        total_failed += n_fail

        status = "PASS" if ok else "FAIL"
        results[check_num] = (status, output, n_pass, n_fail)

        if ok:
            print(f"  PASS  ({n_pass} tests)")
        else:
            print(f"  FAIL  ({n_pass} passed, {n_fail} failed)")

        if args.verbose or not ok:
            # Show relevant lines
            for line in output.split("\n"):
                stripped = line.strip()
                if stripped and not stripped.startswith("  PASS"):
                    print(f"    {line}")

        print()

    # Summary
    print("=" * 70)
    print("SUMMARY")
    print("=" * 70)
    all_pass = True
    critical_fail = False
    for check_num, (status, _, n_pass, n_fail) in results.items():
        check_info = checks_to_run[check_num]
        flag = "✓" if status == "PASS" else ("✗" if status == "FAIL" else "?")
        print(f"  {flag} CHECK {check_num} [{check_info['priority']}]: "
              f"{status} ({n_pass} pass, {n_fail} fail)")
        if status == "FAIL":
            all_pass = False
            if check_info["priority"] == "CRITICAL":
                critical_fail = True

    print()
    print(f"  Total: {total_passed} tests passed, {total_failed} failed")

    if all_pass:
        print()
        print("  All checks passing.")
        print("  Your miner output is correctly aligned with the scoring functions.")
        print("  Next: deploy to Chutes and verify shard log matches local predictions.")
    elif critical_fail:
        print()
        print("  CRITICAL failures detected.")
        print("  Fix CHECK 1 (class mapping) and CHECK 2 (frame alignment) first.")
        print("  These cause silent score loss with no error messages.")
    else:
        print()
        print("  Non-critical failures. Address in priority order.")

    # Update progress.txt
    if args.update_progress:
        ts = datetime.now().strftime("%Y-%m-%d %H:%M")
        lines = [f"# --- run_all_tests.py {ts} ---"]
        for check_num, (status, _, n_pass, n_fail) in results.items():
            desc = checks_to_run[check_num]["description"]
            lines.append(
                f"[CHECK {check_num}] {status} -- "
                f"{n_pass} pass, {n_fail} fail -- {desc}"
            )
        append_progress(progress_file, lines)
        print(f"\n  Progress written to {progress_file}")

    return 0 if all_pass else 1


if __name__ == "__main__":
    sys.exit(main())
