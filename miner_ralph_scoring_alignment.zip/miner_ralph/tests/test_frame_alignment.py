"""
tests/test_frame_alignment.py
CHECK 2 — Frame number alignment

Verifies that miner output frame_ids exactly match the GT frame_numbers
the validator expects. Misalignment causes entire frames to score as
missed detections, tanking map50 with no visible error.

Scoring path tested:
  evaluate.py line 99  (frame_number = predicted_frame.get("frame_id", -1))
  objects.py  line 93  (_build_per_image_rows: miner_predictions.get(frame_number))
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from fixtures.scoring_helpers import (
    ELEMENTS, parse_miner_prediction, build_per_image_rows,
    evaluate_at_threshold, score_full_pipeline,
    Box, PredFrame, GTFrame, GTBox, make_gt_frame, make_pred_frame,
)


# ── Helpers ───────────────────────────────────────────────────────────────────
def _make_perfect_preds(gt_frames, cls_id=0, conf=0.9):
    """Create pred frames with exactly matching frame_ids and tight boxes."""
    return [
        PredFrame(
            frame_id=gf.frame_number,
            boxes=[Box(x1=b.x1, y1=b.y1, x2=b.x2, y2=b.y2,
                       cls_id=cls_id, conf=conf)
                   for b in gf.boxes]
        )
        for gf in gt_frames
    ]


# ── Tests ─────────────────────────────────────────────────────────────────────
def test_matching_frame_ids_produce_nonzero_map50():
    """When frame_ids exactly match GT frame_numbers, map50 > 0."""
    gt_frames = [make_gt_frame(frame_number=i*5, label="person") for i in range(5)]
    pred_frames = _make_perfect_preds(gt_frames)
    result = score_full_pipeline(
        gt_frames, pred_frames, "manak0/Detect-Person")
    assert result["map50"] > 0.5, (
        f"Matching frame_ids should give map50 > 0.5, got {result['map50']:.4f}"
    )


def test_wrong_frame_ids_give_low_map50():
    """
    If miner returns frame_id=0,1,2,3,4 but GT expects frame_id=0,5,10,15,20,
    only frame_id=0 matches. The other 4 frames score as missed detections.
    map50 should be ~1/5 of full-coverage map50.

    NOTE: frame_id=0 will still match GT frame_number=0, so map50 is not
    exactly 0 -- it is approximately full_map50 / n_frames.
    The dangerous bug is an offset error where NONE of the frame_ids match
    (e.g. pred returns 1..5 but GT is 0..4).
    """
    gt_frames = [make_gt_frame(frame_number=i*5, label="person")
                 for i in range(5)]

    # Wrong offset: 0,1,2,3,4 instead of 0,5,10,15,20
    # frame_id=0 will match GT frame_number=0 (one hit out of five)
    pred_frames_wrong = [
        PredFrame(
            frame_id=i,  # WRONG -- should be i*5
            boxes=[Box(x1=b.x1, y1=b.y1, x2=b.x2, y2=b.y2,
                       cls_id=0, conf=0.9)
                   for b in gf.boxes]
        )
        for i, gf in enumerate(gt_frames)
    ]

    # Correct offset
    pred_frames_correct = [
        PredFrame(
            frame_id=i*5,  # CORRECT
            boxes=[Box(x1=b.x1, y1=b.y1, x2=b.x2, y2=b.y2,
                       cls_id=0, conf=0.9)
                   for b in gf.boxes]
        )
        for i, gf in enumerate(gt_frames)
    ]

    result_wrong   = score_full_pipeline(gt_frames, pred_frames_wrong,   "manak0/Detect-Person")
    result_correct = score_full_pipeline(gt_frames, pred_frames_correct, "manak0/Detect-Person")

    # Wrong offset: only 1/5 frames matched -> map50 ~= correct/5
    assert result_wrong["map50"] < result_correct["map50"] * 0.5, (
        f"Wrong frame_ids should give map50 < half of correct. "
        f"Wrong: {result_wrong['map50']:.4f}, Correct: {result_correct['map50']:.4f}. "
        "Check your miner's frame_id = offset + batch_index arithmetic."
    )

    # Total no-match: pred returns 1..5 when GT is 0,5,10,15,20
    # frame_id=5 will match GT frame_number=5 -- still one hit
    # The zero-map50 case requires NO overlap at all
    pred_no_match = [
        PredFrame(
            frame_id=i + 100,  # completely out of range -- no frame matches
            boxes=[Box(x1=b.x1, y1=b.y1, x2=b.x2, y2=b.y2,
                       cls_id=0, conf=0.9)
                   for b in gf.boxes]
        )
        for i, gf in enumerate(gt_frames)
    ]
    result_no_match = score_full_pipeline(
        gt_frames, pred_no_match, "manak0/Detect-Person")
    assert result_no_match["map50"] == 0.0, (
        f"Frame_ids with no overlap should give map50=0.0, "
        f"got {result_no_match['map50']:.4f}."
    )


def test_partial_frame_coverage_reduces_map50():
    """
    If miner only returns predictions for half the GT frames,
    map50 is approximately halved vs full coverage.
    Simulates a miner that drops frames during batch processing.
    """
    gt_frames = [make_gt_frame(frame_number=i, label="person") for i in range(10)]
    # Only cover even frames
    pred_frames = [
        PredFrame(
            frame_id=gf.frame_number,
            boxes=[Box(x1=b.x1, y1=b.y1, x2=b.x2, y2=b.y2,
                       cls_id=0, conf=0.9)
                   for b in gf.boxes]
        )
        for gf in gt_frames if gf.frame_number % 2 == 0
    ]
    result_partial = score_full_pipeline(
        gt_frames, pred_frames, "manak0/Detect-Person")
    result_full = score_full_pipeline(
        gt_frames, _make_perfect_preds(gt_frames), "manak0/Detect-Person")

    assert result_partial["map50"] < result_full["map50"], (
        f"Partial coverage ({result_partial['map50']:.4f}) should be less than "
        f"full coverage ({result_full['map50']:.4f})."
    )


def test_default_frame_id_fallback_is_minus_one():
    """
    parse_miner_prediction uses frame_id=-1 as fallback if frame_id missing.
    A frame_id=-1 will never match any GT frame_number (which start at 0).
    This verifies the exact fallback behaviour.
    """
    cfg = ELEMENTS["manak0/Detect-Person"]
    # Simulate a frame dict with no frame_id key
    pred_frames_raw = [{"boxes": [{"cls_id": 0, "x1": 10, "y1": 10,
                                    "x2": 100, "y2": 200, "conf": 0.9}]}]

    # Manually call the logic (mirrors evaluate.py line 99)
    frame_number = pred_frames_raw[0].get("frame_id", -1)
    assert frame_number == -1, (
        f"Expected fallback frame_id=-1, got {frame_number}. "
        "This frame's predictions will never match any GT frame."
    )


def test_frame_id_matches_challenge_offset():
    """
    In the example miner, frame_id = offset + frame_number_in_batch.
    Verify that this arithmetic produces frame_ids matching the challenge.

    The challenge sends frames with specific IDs (e.g. 0,1,2..29 for 30 frames).
    The miner must return exactly those IDs.
    """
    # Simulate a 30-frame challenge (standard for these elements)
    challenge_frame_ids = list(range(30))

    # Correct: offset=0, batch processes frames 0..29
    offset = 0
    batch_size = 10
    returned_frame_ids = []
    for batch_start in range(0, 30, batch_size):
        batch_end = min(batch_start + batch_size, 30)
        for i in range(batch_end - batch_start):
            returned_frame_ids.append(offset + batch_start + i)

    assert returned_frame_ids == challenge_frame_ids, (
        f"Frame ID mismatch.\n"
        f"Challenge: {challenge_frame_ids}\n"
        f"Returned:  {returned_frame_ids}"
    )


def test_build_per_image_rows_count_equals_gt_count():
    """
    _build_per_image_rows always produces exactly len(gt_frames) rows.
    Missing predictions -> empty predictions for that row (not missing row).
    This means n_images in ffpi calculation = n_gt_frames always.
    """
    gt_frames = [make_gt_frame(frame_number=i, label="person") for i in range(30)]
    # No predictions at all
    rows = build_per_image_rows(gt_frames, parsed_predictions={})
    assert len(rows) == 30, (
        f"Expected 30 rows from 30 GT frames with empty predictions, "
        f"got {len(rows)}."
    )
    # All predictions empty
    for row in rows:
        assert row["predictions"] == [], (
            "Expected empty predictions for frames with no miner output."
        )


def test_empty_predictions_produce_fp_zero_and_map50_zero():
    """
    No miner predictions = no TPs, no FPs, no AP.
    map50 = 0.0 (no predictions to rank)
    fp_score = 1.0 (ffpi = 0/30 = 0, fp_score = max(0, 1-0/10) = 1.0)
    This is an important edge case: total silence doesn't hurt fp_score.
    """
    gt_frames = [make_gt_frame(frame_number=i, label="person") for i in range(30)]
    rows = build_per_image_rows(gt_frames, parsed_predictions={})
    metrics = evaluate_at_threshold(rows)

    assert metrics["map50"] == 0.0, (
        f"Empty predictions should give map50=0.0, got {metrics['map50']:.4f}"
    )
    assert metrics["fp_score"] == 1.0, (
        f"Empty predictions have 0 FPs so fp_score should be 1.0, "
        f"got {metrics['fp_score']:.4f}"
    )
    # total_weighted with map50=0, fp=1.0 for person:
    # 0.65*0 + 0.35*1.0 = 0.35, still below theta=0.3755
    from fixtures.scoring_helpers import weight_score
    gating = weight_score(0.0, 1.0, "manak0/Detect-Person")
    assert not gating["above_theta"], (
        "Empty predictions (map50=0, fp=1.0) should be below theta=0.3755. "
        f"total_weighted = {gating['total_weighted']:.4f}"
    )


if __name__ == "__main__":
    tests = [
        test_matching_frame_ids_produce_nonzero_map50,
        test_wrong_frame_ids_give_low_map50,
        test_partial_frame_coverage_reduces_map50,
        test_default_frame_id_fallback_is_minus_one,
        test_frame_id_matches_challenge_offset,
        test_build_per_image_rows_count_equals_gt_count,
        test_empty_predictions_produce_fp_zero_and_map50_zero,
    ]
    passed, failed = 0, 0
    for test in tests:
        try:
            test()
            print(f"  PASS  {test.__name__}")
            passed += 1
        except AssertionError as e:
            print(f"  FAIL  {test.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"  ERROR {test.__name__}: {e}")
            failed += 1
    print(f"\n{passed} passed, {failed} failed")
    sys.exit(0 if failed == 0 else 1)
