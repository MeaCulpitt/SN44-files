"""
tests/test_confidence_and_gate.py
CHECK 3 + CHECK 5 + CHECK 6 — Confidence scores, FP budget, gate computation

Three tightly related checks combined because they all depend on the
same AP computation path:

CHECK 3: Confidence scores are valid and influence AP ranking
  objects.py lines 178-181 (sort by score descending)
  evaluate.py line 132     (bbox.get("score", bbox.get("conf")))

CHECK 5: FP count at current threshold produces viable fp_score
  objects.py line 240  (ffpi = global_FP / len(per_image))
  objects.py line 268  (false_positive = max(0, 1 - ffpi/10))

CHECK 6: weight_score() gate computation matches expected gated score
  manifest.py lines 344-358
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from fixtures.scoring_helpers import (
    ELEMENTS, evaluate_at_threshold, build_per_image_rows,
    weight_score, score_full_pipeline,
    Box, PredFrame, GTBox, GTFrame, make_gt_frame, make_pred_frame,
    parse_miner_prediction,
)


# ── CHECK 3: Confidence scores ────────────────────────────────────────────────
def test_missing_score_defaults_to_one():
    """
    If conf/score field is missing, _safe_detection_score defaults to 1.0.
    This means ALL boxes have the same score -> AP curve degenerates to
    a single precision value. Verify this causes lower AP than ranked scores.
    """
    gt_frames = [make_gt_frame(frame_number=i, label="person") for i in range(10)]

    # Good: boxes have varying confidence (higher conf = better box)
    pred_good = []
    for gf in gt_frames:
        boxes = []
        for j, b in enumerate(gf.boxes):
            conf = 0.9 - j * 0.1  # decreasing confidence
            boxes.append(Box(x1=b.x1, y1=b.y1, x2=b.x2, y2=b.y2,
                             cls_id=0, conf=conf))
        pred_good.append(PredFrame(frame_id=gf.frame_number, boxes=boxes))

    # Bad: all boxes have conf=1.0 (undifferentiated -- fields missing equiv.)
    pred_flat = []
    for gf in gt_frames:
        boxes = [Box(x1=b.x1, y1=b.y1, x2=b.x2, y2=b.y2, cls_id=0, conf=1.0)
                 for b in gf.boxes]
        pred_flat.append(PredFrame(frame_id=gf.frame_number, boxes=boxes))

    result_good = score_full_pipeline(
        gt_frames, pred_good, "manak0/Detect-Person")
    result_flat = score_full_pipeline(
        gt_frames, pred_flat, "manak0/Detect-Person")

    # Both should be positive (tight boxes) but good should be >= flat
    assert result_good["map50"] >= 0.0
    assert result_flat["map50"] >= 0.0
    print(f"  Ranked conf map50: {result_good['map50']:.4f}")
    print(f"  Flat conf map50:   {result_flat['map50']:.4f}")


def test_score_field_takes_priority_over_conf():
    """
    evaluate.py reads bbox.get("score", bbox.get("conf")).
    If your miner outputs BOTH score and conf, 'score' wins.
    Verify the precedence is what your miner produces.
    """
    cfg = ELEMENTS["manak0/Detect-Person"]
    # Simulate what parse_miner_prediction reads
    # (mirroring evaluate.py line 132)
    bbox_with_score = {"score": 0.95, "conf": 0.30, "cls_id": 0,
                       "x1": 10, "y1": 10, "x2": 100, "y2": 200}
    bbox_conf_only  = {"conf": 0.75, "cls_id": 0,
                       "x1": 10, "y1": 10, "x2": 100, "y2": 200}
    bbox_neither    = {"cls_id": 0,
                       "x1": 10, "y1": 10, "x2": 100, "y2": 200}

    # Replicate the exact read logic from evaluate.py
    score_a = bbox_with_score.get("score", bbox_with_score.get("conf"))
    score_b = bbox_conf_only.get("score", bbox_conf_only.get("conf"))
    score_c = bbox_neither.get("score", bbox_neither.get("conf"))

    assert score_a == 0.95, f"'score' key should take priority, got {score_a}"
    assert score_b == 0.75, f"'conf' fallback should work, got {score_b}"
    assert score_c is None, (
        f"Neither 'score' nor 'conf' should return None, got {score_c}. "
        "This will default to 1.0 in _safe_detection_score -- all boxes "
        "treated as maximum confidence."
    )


def test_all_confidence_scores_in_valid_range():
    """Confidence scores must be in [0.0, 1.0] -- NaN/Inf corrupt AP."""
    import math
    gt_frames = [make_gt_frame(frame_number=i, label="person") for i in range(5)]
    pred_frames = [make_pred_frame(gf.frame_number, gf) for gf in gt_frames]

    cfg = ELEMENTS["manak0/Detect-Person"]
    parsed = parse_miner_prediction(pred_frames, cfg["objects"])
    for frame_id, boxes in parsed.items():
        for box in boxes:
            score = box["score"]
            assert score is not None, f"score is None for frame {frame_id}"
            assert 0.0 <= score <= 1.0, (
                f"score={score} out of [0,1] for frame {frame_id}"
            )
            assert not math.isnan(score), f"score is NaN for frame {frame_id}"
            assert not math.isinf(score), f"score is Inf for frame {frame_id}"


# ── CHECK 5: FP budget ────────────────────────────────────────────────────────
def test_fp_score_formula():
    """
    Verify fp_score = max(0, 1 - ffpi/10) is correctly implemented.
    ffpi = global_FP / n_images (n_images = 30 for both elements).
    """
    # Manual verification of the formula
    cases = [
        (0.0, 1.0),   # 0 FPs/image -> fp_score=1.0
        (1.0, 0.9),   # 1 FP/image  -> fp_score=0.9
        (1.5, 0.85),  # 1.5 FP/img  -> fp_score=0.85 (target)
        (5.0, 0.5),   # 5 FP/image  -> fp_score=0.5  (baseline person)
        (6.0, 0.4),   # 6 FP/image  -> fp_score=0.4  (baseline vehicle)
        (10.0, 0.0),  # 10 FP/image -> fp_score=0.0
        (15.0, 0.0),  # >10 FP/img  -> clamped to 0.0
    ]
    for ffpi, expected_fp in cases:
        computed = max(0.0, 1.0 - ffpi / 10.0)
        assert abs(computed - expected_fp) < 1e-9, (
            f"ffpi={ffpi}: expected fp_score={expected_fp}, "
            f"got {computed:.4f}"
        )


def test_fp_score_above_baseline_for_person():
    """
    Detect-Person baseline fp=0.50 means 5 FPs/image.
    At target conf threshold, verify fp_score >= 0.75.
    """
    n_images = 30
    # Simulate 30 images with 2 FPs each (fp_score = 1 - 2/10 = 0.8)
    gt_frames = [make_gt_frame(frame_number=i, label="person", n_objects=3)
                 for i in range(n_images)]
    pred_frames = [
        make_pred_frame(gf.frame_number, gf, n_extra_fp=2)
        for gf in gt_frames
    ]
    result = score_full_pipeline(
        gt_frames, pred_frames, "manak0/Detect-Person")

    assert result["fp_score"] >= 0.75, (
        f"fp_score={result['fp_score']:.4f} is too low. "
        f"ffpi={result['ffpi']:.2f} FPs/image. "
        f"Target: fp_score >= 0.75 (ffpi <= 2.5). "
        f"Reduce FPs by raising confidence threshold."
    )


def test_fp_score_above_baseline_for_vehicle():
    """
    Detect-Vehicle baseline fp=0.40 means 6 FPs/image.
    At target conf threshold, verify fp_score >= 0.75.
    Vehicle fp weight is 0.40 (vs 0.35 for person) so FP control matters more.
    """
    n_images = 30
    cfg = ELEMENTS["manak0/Detect-detect-vehicle"]
    gt_frames = [make_gt_frame(frame_number=i, label=cfg["objects"][0],
                               n_objects=3)
                 for i in range(n_images)]
    pred_frames = [
        make_pred_frame(gf.frame_number, gf, n_extra_fp=2)
        for gf in gt_frames
    ]
    result = score_full_pipeline(
        gt_frames, pred_frames, "manak0/Detect-detect-vehicle")

    assert result["fp_score"] >= 0.75, (
        f"fp_score={result['fp_score']:.4f} is too low for vehicle. "
        f"ffpi={result['ffpi']:.2f} FPs/image. "
        f"Vehicle fp weight=0.40 -- FP control is more critical than person."
    )


def test_confidence_threshold_tradeoff_person():
    """
    Sweep confidence threshold and verify total_weighted peaks in [0.40, 0.50].
    At low threshold: high recall but many FPs (fp_score drops).
    At high threshold: few FPs but poor recall (map50 drops).
    w_map50=0.65 dominates for person.
    """
    n_images = 30
    gt_frames = [make_gt_frame(frame_number=i, label="person", n_objects=3)
                 for i in range(n_images)]

    results = {}
    for conf_threshold in [0.20, 0.30, 0.40, 0.45, 0.50, 0.60]:
        # Simulate: lower threshold -> more FPs, higher threshold -> misses
        fp_per_image = max(0, 8 - conf_threshold * 12)  # rough model
        misses_per_image = max(0, conf_threshold - 0.3) * 2.5
        n_fp = int(fp_per_image)
        n_miss = int(misses_per_image * 3)

        pred_frames = []
        for gf in gt_frames:
            kept_boxes = gf.boxes[n_miss:] if n_miss < len(gf.boxes) else []
            boxes = [
                Box(x1=b.x1, y1=b.y1, x2=b.x2, y2=b.y2,
                    cls_id=0, conf=conf_threshold)
                for b in kept_boxes
            ]
            for i in range(n_fp):
                boxes.append(Box(x1=i*30+5, y1=5, x2=i*30+35, y2=55,
                                 cls_id=0, conf=conf_threshold * 0.5))
            pred_frames.append(PredFrame(frame_id=gf.frame_number, boxes=boxes))

        result = score_full_pipeline(
            gt_frames, pred_frames, "manak0/Detect-Person")
        results[conf_threshold] = result["total_weighted"]
        print(f"  conf={conf_threshold:.2f}: "
              f"map50={result['map50']:.3f}, "
              f"fp={result['fp_score']:.3f}, "
              f"total_w={result['total_weighted']:.4f}, "
              f"gated={result['gated']:.4f}")

    best_conf = max(results, key=results.get)
    print(f"  Best conf threshold: {best_conf:.2f} "
          f"(total_w={results[best_conf]:.4f})")
    assert 0.35 <= best_conf <= 0.55, (
        f"Expected optimal threshold in [0.35, 0.55], found {best_conf}. "
        "Investigate conf sweep on real replay buffer."
    )


# ── CHECK 6: Gate computation ─────────────────────────────────────────────────
def test_weight_score_formula_person():
    """
    weight_score for Detect-Person:
    total = 0.65*map50 + 0.35*fp
    gated = max(max(total - 0.3755, 0), 0.01)
    """
    cases = [
        # (map50, fp, expected_total, expected_gated)
        (0.0,  0.0,  0.0000, 0.0100),  # below theta -> delta_floor
        (0.38, 0.70, 0.4920, 0.1165),  # after class fix
        (0.65, 0.80, 0.7025, 0.3270),  # after threshold tune
        (0.85, 0.85, 0.8500, 0.4745),  # at target
    ]
    for map50, fp, exp_total, exp_gated in cases:
        result = weight_score(map50, fp, "manak0/Detect-Person")
        assert abs(result["total_weighted"] - exp_total) < 1e-4, (
            f"map50={map50}, fp={fp}: "
            f"total_weighted={result['total_weighted']:.4f}, "
            f"expected {exp_total:.4f}"
        )
        assert abs(result["gated"] - exp_gated) < 1e-4, (
            f"map50={map50}, fp={fp}: "
            f"gated={result['gated']:.4f}, expected {exp_gated:.4f}"
        )


def test_weight_score_formula_vehicle():
    """
    weight_score for Detect-Vehicle:
    total = 0.60*map50 + 0.40*fp
    gated = max(max(total - 0.4072, 0), 0.01)
    """
    cases = [
        # (map50, fp, expected_total, expected_gated)
        (0.0,  0.0,  0.0000, 0.0100),  # below theta -> delta_floor
        (0.42, 0.55, 0.4720, 0.0648),  # after class fix
        (0.65, 0.76, 0.6940, 0.2868),  # after domain fine-tune
        (0.90, 0.90, 0.9000, 0.4928),  # at target
    ]
    for map50, fp, exp_total, exp_gated in cases:
        result = weight_score(map50, fp, "manak0/Detect-detect-vehicle")
        assert abs(result["total_weighted"] - exp_total) < 1e-4, (
            f"map50={map50}, fp={fp}: "
            f"total_weighted={result['total_weighted']:.4f}, "
            f"expected {exp_total:.4f}"
        )
        assert abs(result["gated"] - exp_gated) < 1e-4, (
            f"map50={map50}, fp={fp}: "
            f"gated={result['gated']:.4f}, expected {exp_gated:.4f}"
        )


def test_delta_floor_kicks_in_below_theta():
    """
    Below baseline_theta, gated = delta_floor = 0.01 (not 0).
    This is critical: the agent uses gated > delta_floor as the signal
    that it has crossed the gate.
    """
    for eid in ELEMENTS:
        result = weight_score(0.0, 0.0, eid)
        cfg = ELEMENTS[eid]
        assert abs(result["gated"] - cfg["delta_floor"]) < 1e-9, (
            f"{eid}: below theta should give delta_floor={cfg['delta_floor']}, "
            f"got {result['gated']:.6f}"
        )
        assert not result["above_theta"], (
            f"{eid}: score=0 should be below theta."
        )


def test_total_weighted_must_exceed_theta_for_real_emissions():
    """
    Verify the minimum map50+fp combination needed to cross theta.
    At map50=0.38 (stock YOLOv8n with correct mapping), what fp is needed?
    """
    # Person: 0.65*0.38 + 0.35*fp > 0.3755
    # 0.35*fp > 0.3755 - 0.247 = 0.1285
    # fp > 0.367
    map50_person = 0.38
    min_fp_person = (ELEMENTS["manak0/Detect-Person"]["baseline_theta"]
                     - map50_person * 0.65) / 0.35
    result = weight_score(map50_person, min_fp_person + 0.01,
                          "manak0/Detect-Person")
    assert result["above_theta"], (
        f"With map50={map50_person}, fp>={min_fp_person:.3f} should cross theta"
    )
    print(f"  Person: at map50={map50_person}, need fp > {min_fp_person:.3f} "
          f"to cross theta")

    # Vehicle: 0.60*0.42 + 0.40*fp > 0.4072
    map50_vehicle = 0.42
    min_fp_vehicle = (ELEMENTS["manak0/Detect-detect-vehicle"]["baseline_theta"]
                      - map50_vehicle * 0.60) / 0.40
    result_v = weight_score(map50_vehicle, min_fp_vehicle + 0.01,
                            "manak0/Detect-detect-vehicle")
    assert result_v["above_theta"], (
        f"With map50={map50_vehicle}, fp>={min_fp_vehicle:.3f} should cross theta"
    )
    print(f"  Vehicle: at map50={map50_vehicle}, need fp > {min_fp_vehicle:.3f} "
          f"to cross theta")


if __name__ == "__main__":
    tests = [
        test_missing_score_defaults_to_one,
        test_score_field_takes_priority_over_conf,
        test_all_confidence_scores_in_valid_range,
        test_fp_score_formula,
        test_fp_score_above_baseline_for_person,
        test_fp_score_above_baseline_for_vehicle,
        test_confidence_threshold_tradeoff_person,
        test_weight_score_formula_person,
        test_weight_score_formula_vehicle,
        test_delta_floor_kicks_in_below_theta,
        test_total_weighted_must_exceed_theta_for_real_emissions,
    ]
    passed, failed = 0, 0
    for test in tests:
        try:
            test()
            print(f"  PASS  {test.__name__}")
            passed += 1
        except AssertionError as e:
            print(f"  FAIL  {test.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"  ERROR {test.__name__}: {e}")
            failed += 1
    print(f"\n{passed} passed, {failed} failed")
    sys.exit(0 if failed == 0 else 1)
