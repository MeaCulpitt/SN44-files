"""
tests/test_class_mapping.py
CHECK 1 — Class mapping

Verifies that your miner's cls_id output correctly maps to the string
the validator expects via element.objects.

Scoring path tested:
  evaluate.py lines 100-113 (parse_miner_prediction cls_id lookup)
  objects.py  lines 99, 106 (_normalize_class_name on label)

Both elements tested: Detect-Person and Detect-Vehicle.
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from fixtures.scoring_helpers import (
    ELEMENTS, normalize_class_name, parse_miner_prediction,
    Box, PredFrame, make_gt_frame, score_full_pipeline,
)


# ── Helpers ───────────────────────────────────────────────────────────────────
def _make_single_pred(frame_id: int, cls_id: int, conf: float = 0.9) -> PredFrame:
    return PredFrame(
        frame_id=frame_id,
        boxes=[Box(x1=10, y1=10, x2=100, y2=200, cls_id=cls_id, conf=conf)]
    )


# ── Tests for Detect-Person ───────────────────────────────────────────────────
def test_person_objects_list_is_correct():
    """element.objects for Detect-Person must contain 'person' at index 0."""
    cfg = ELEMENTS["manak0/Detect-Person"]
    assert cfg["objects"][0] == "person", (
        f"element.objects[0] = '{cfg['objects'][0]}', expected 'person'. "
        "This will cause every detection to be silently dropped."
    )


def test_person_cls_id_zero_maps_to_person():
    """cls_id=0 must map to 'person' after normalize_class_name."""
    cfg = ELEMENTS["manak0/Detect-Person"]
    label = cfg["objects"][0]
    assert normalize_class_name(label) == "person", (
        f"normalize_class_name('{label}') = '{normalize_class_name(label)}', "
        "expected 'person'. Check for whitespace or capitalisation."
    )


def test_person_valid_cls_id_survives_parsing():
    """A box with cls_id=0 must NOT be dropped by parse_miner_prediction."""
    cfg = ELEMENTS["manak0/Detect-Person"]
    pred_frames = [_make_single_pred(frame_id=1, cls_id=0)]
    result = parse_miner_prediction(pred_frames, cfg["objects"])
    assert 1 in result, "Frame 1 missing from parsed output"
    assert len(result[1]) == 1, (
        f"Expected 1 parsed box, got {len(result[1])}. "
        "Box was silently dropped despite valid cls_id=0."
    )
    assert result[1][0]["class"] == "person", (
        f"Parsed class = '{result[1][0]['class']}', expected 'person'."
    )


def test_person_out_of_range_cls_id_is_dropped():
    """cls_id=1 (out of range for single-class element) must be dropped silently."""
    cfg = ELEMENTS["manak0/Detect-Person"]
    pred_frames = [_make_single_pred(frame_id=1, cls_id=1)]  # only 1 class
    result = parse_miner_prediction(pred_frames, cfg["objects"])
    boxes = result.get(1, [])
    assert len(boxes) == 0, (
        f"Expected 0 boxes (cls_id=1 out of range), got {len(boxes)}. "
        "Validator would drop these silently -- this is correct behaviour."
    )


def test_person_negative_cls_id_is_dropped():
    """Negative cls_id must be dropped (parse_miner_prediction line 110)."""
    cfg = ELEMENTS["manak0/Detect-Person"]
    pred_frames = [_make_single_pred(frame_id=1, cls_id=-1)]
    result = parse_miner_prediction(pred_frames, cfg["objects"])
    boxes = result.get(1, [])
    assert len(boxes) == 0, (
        f"Expected 0 boxes for cls_id=-1, got {len(boxes)}."
    )


def test_person_wrong_class_gets_zero_map50():
    """
    If your model outputs cls_id=0 but element.objects[0] is wrong
    (e.g. 'car' instead of 'person'), map50 drops to 0.
    This test verifies the class name mismatch path.
    """
    # Simulate wrong objects list
    wrong_objects = ["car"]  # mismatch with GT label "person"
    gt_frames = [make_gt_frame(frame_number=i, label="person") for i in range(5)]
    pred_frames = [
        PredFrame(frame_id=gf.frame_number, boxes=[
            Box(x1=b.x1, y1=b.y1, x2=b.x2, y2=b.y2, cls_id=0, conf=0.9)
            for b in gf.boxes
        ])
        for gf in gt_frames
    ]
    parsed = parse_miner_prediction(pred_frames, wrong_objects)

    from fixtures.scoring_helpers import build_per_image_rows, evaluate_at_threshold
    rows = build_per_image_rows(gt_frames, parsed)
    metrics = evaluate_at_threshold(rows)

    assert metrics["map50"] == 0.0, (
        f"Expected map50=0.0 with class mismatch (pred='car', gt='person'), "
        f"got {metrics['map50']:.4f}. Class mismatch should produce zero AP."
    )


def test_person_correct_mapping_produces_nonzero_map50():
    """
    End-to-end: correct cls_id=0 -> 'person' mapping with good boxes
    must produce map50 > 0.
    """
    gt_frames = [make_gt_frame(frame_number=i, label="person") for i in range(5)]
    pred_frames = [
        PredFrame(frame_id=gf.frame_number, boxes=[
            Box(x1=b.x1, y1=b.y1, x2=b.x2, y2=b.y2, cls_id=0, conf=0.9)
            for b in gf.boxes
        ])
        for gf in gt_frames
    ]
    result = score_full_pipeline(gt_frames, pred_frames, "manak0/Detect-Person")
    assert result["map50"] > 0.5, (
        f"Expected map50 > 0.5 with correct mapping and tight boxes, "
        f"got {result['map50']:.4f}."
    )


# ── Tests for Detect-Vehicle ──────────────────────────────────────────────────
def test_vehicle_objects_list_is_correct():
    """element.objects for Detect-Vehicle must contain the expected vehicle class."""
    cfg = ELEMENTS["manak0/Detect-detect-vehicle"]
    assert len(cfg["objects"]) > 0, "element.objects is empty for Detect-Vehicle"
    # Confirm against live manifest -- update this string if manifest changes
    expected = cfg["objects"][0]
    assert normalize_class_name(expected) == normalize_class_name(expected), (
        "element.objects[0] must normalise consistently."
    )
    print(f"  Detect-Vehicle element.objects[0] = '{expected}' -- "
          "verify this matches the live manifest")


def test_vehicle_cls_id_zero_survives_parsing():
    """cls_id=0 must map to the vehicle class and not be dropped."""
    cfg = ELEMENTS["manak0/Detect-detect-vehicle"]
    pred_frames = [_make_single_pred(frame_id=1, cls_id=0)]
    result = parse_miner_prediction(pred_frames, cfg["objects"])
    assert 1 in result, "Frame 1 missing from parsed output"
    assert len(result[1]) == 1, (
        f"Expected 1 parsed box, got {len(result[1])}. "
        f"cls_id=0 was dropped for Detect-Vehicle."
    )


def test_vehicle_correct_mapping_produces_nonzero_map50():
    """End-to-end: correct mapping for vehicle must produce map50 > 0."""
    cfg = ELEMENTS["manak0/Detect-detect-vehicle"]
    vehicle_label = cfg["objects"][0]
    gt_frames = [make_gt_frame(frame_number=i, label=vehicle_label) for i in range(5)]
    pred_frames = [
        PredFrame(frame_id=gf.frame_number, boxes=[
            Box(x1=b.x1, y1=b.y1, x2=b.x2, y2=b.y2, cls_id=0, conf=0.9)
            for b in gf.boxes
        ])
        for gf in gt_frames
    ]
    result = score_full_pipeline(
        gt_frames, pred_frames, "manak0/Detect-detect-vehicle")
    assert result["map50"] > 0.5, (
        f"Expected map50 > 0.5 for vehicle, got {result['map50']:.4f}."
    )


# ── Cross-element: both elements use the same scoring path ────────────────────
def test_both_elements_share_same_scoring_path():
    """
    Verify that Detect-Person and Detect-Vehicle both route through
    compare_map50 and compare_false_positive -- no other pillars active.
    The manifest only defines map50 and false_positive weights.
    """
    for eid, cfg in ELEMENTS.items():
        assert "w_map50" in cfg, f"{eid} missing w_map50"
        assert "w_fp" in cfg, f"{eid} missing w_fp"
        assert abs(cfg["w_map50"] + cfg["w_fp"] - 1.0) < 1e-9, (
            f"{eid} pillar weights don't sum to 1.0: "
            f"w_map50={cfg['w_map50']}, w_fp={cfg['w_fp']}"
        )


if __name__ == "__main__":
    tests = [
        test_person_objects_list_is_correct,
        test_person_cls_id_zero_maps_to_person,
        test_person_valid_cls_id_survives_parsing,
        test_person_out_of_range_cls_id_is_dropped,
        test_person_negative_cls_id_is_dropped,
        test_person_wrong_class_gets_zero_map50,
        test_person_correct_mapping_produces_nonzero_map50,
        test_vehicle_objects_list_is_correct,
        test_vehicle_cls_id_zero_survives_parsing,
        test_vehicle_correct_mapping_produces_nonzero_map50,
        test_both_elements_share_same_scoring_path,
    ]
    passed, failed = 0, 0
    for test in tests:
        try:
            test()
            print(f"  PASS  {test.__name__}")
            passed += 1
        except AssertionError as e:
            print(f"  FAIL  {test.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"  ERROR {test.__name__}: {e}")
            failed += 1
    print(f"\n{passed} passed, {failed} failed")
    sys.exit(0 if failed == 0 else 1)
