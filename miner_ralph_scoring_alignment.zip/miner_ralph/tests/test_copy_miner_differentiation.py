"""
tests/test_copy_miner_differentiation.py
CHECK 7 — Copy-miner differentiation

Verifies that your per-challenge score vector is sufficiently different
from the current winner's to avoid the copy-miner tiebreak penalty.

Scoring path tested:
  scoring.py lines 43-65 (are_similar_by_challenges)
  scoring.py lines 156-226 (pick_winner_with_tiebreak)

From the source (scoring.py line 50-64):
  For each common challenge:
    max_score = max(|s1|, |s2|)
    threshold = max(delta_abs, delta_rel * max_score)
    if |s1 - s2| > threshold: NOT similar (good)
  If all common challenges within threshold AND >= min_common: flagged as similar
  Flagged as similar -> tiebreak by first_commit_block (earlier wins)

Live manifest values:
  delta_abs = 0.02
  delta_rel = 0.05
  min_common_challenges = 5
"""
import sys
import os
import random
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from fixtures.scoring_helpers import ELEMENTS


# ── Replica of are_similar_by_challenges (scoring.py lines 43-65) ────────────
DELTA_ABS = 0.02
DELTA_REL = 0.05
MIN_COMMON = 5


def are_similar_by_challenges(
    scores1: dict,
    scores2: dict,
    delta_abs: float = DELTA_ABS,
    delta_rel: float = DELTA_REL,
    min_common: int = MIN_COMMON,
) -> tuple[bool, dict]:
    """
    Exact replica of scoring.py are_similar_by_challenges + debug version.
    Returns (is_similar, debug_info).
    """
    common = []
    all_ids = set(scores1.keys()) | set(scores2.keys())
    for cid in all_ids:
        s1 = float(scores1.get(cid, 0.0) or 0.0)
        s2 = float(scores2.get(cid, 0.0) or 0.0)
        if abs(s1) > 1e-9 and abs(s2) > 1e-9:
            common.append((cid, s1, s2))

    if len(common) < min_common:
        return False, {
            "reason": "insufficient_common_challenges",
            "n_common": len(common),
            "min_required": min_common,
        }

    failed_count = 0
    details = []
    for cid, s1, s2 in common:
        max_score = max(abs(s1), abs(s2))
        threshold = max(delta_abs, delta_rel * max_score)
        diff = abs(s1 - s2)
        passes = diff > threshold
        if passes:
            failed_count += 1
        details.append({
            "challenge_id": cid,
            "s1": round(s1, 4),
            "s2": round(s2, 4),
            "diff": round(diff, 4),
            "threshold": round(threshold, 4),
            "differentiated": passes,
        })

    is_similar = failed_count == 0
    return is_similar, {
        "reason": "all_within_threshold" if is_similar else "score_delta_exceeded",
        "n_common": len(common),
        "n_differentiated": failed_count,
        "pct_differentiated": failed_count / len(common) if common else 0,
        "details": details[:5],  # first 5 for debugging
    }


# ── Tests ─────────────────────────────────────────────────────────────────────
def test_identical_scores_are_similar():
    """Identical per-challenge scores -> flagged as copy-miner."""
    scores = {f"challenge_{i}": 0.42 + i * 0.01 for i in range(10)}
    similar, info = are_similar_by_challenges(scores, scores)
    assert similar, (
        f"Identical scores should be flagged as similar. Got: {info}"
    )


def test_large_deltas_are_not_similar():
    """Per-challenge deltas > delta_abs=0.02 consistently -> NOT similar."""
    scores1 = {f"ch_{i}": 0.50 for i in range(10)}
    scores2 = {f"ch_{i}": 0.50 + 0.05 for i in range(10)}  # +0.05 everywhere
    similar, info = are_similar_by_challenges(scores1, scores2)
    assert not similar, (
        f"Consistent +0.05 delta should NOT be similar. Got: {info}"
    )


def test_threshold_is_max_of_abs_and_rel():
    """
    Threshold = max(delta_abs=0.02, delta_rel*max_score).
    At score=0.10: threshold = max(0.02, 0.05*0.10) = max(0.02, 0.005) = 0.02
    At score=0.80: threshold = max(0.02, 0.05*0.80) = max(0.02, 0.04) = 0.04
    """
    # Low score: absolute threshold dominates
    scores1 = {f"ch_{i}": 0.10 for i in range(10)}
    scores2 = {f"ch_{i}": 0.10 + 0.019 for i in range(10)}  # just under delta_abs
    similar_low, _ = are_similar_by_challenges(scores1, scores2)
    assert similar_low, "Delta 0.019 < delta_abs=0.02 should be similar at low scores"

    scores2_over = {f"ch_{i}": 0.10 + 0.021 for i in range(10)}  # just over delta_abs
    similar_low_over, _ = are_similar_by_challenges(scores1, scores2_over)
    assert not similar_low_over, "Delta 0.021 > delta_abs=0.02 should NOT be similar"

    # High score: relative threshold dominates
    scores3 = {f"ch_{i}": 0.80 for i in range(10)}
    scores4 = {f"ch_{i}": 0.80 + 0.035 for i in range(10)}  # < 0.05*0.80=0.04
    similar_high, _ = are_similar_by_challenges(scores3, scores4)
    assert similar_high, "Delta 0.035 < rel_threshold=0.04 should be similar at high scores"

    scores4_over = {f"ch_{i}": 0.80 + 0.045 for i in range(10)}  # > 0.04
    similar_high_over, _ = are_similar_by_challenges(scores3, scores4_over)
    assert not similar_high_over, "Delta 0.045 > rel_threshold=0.04 should NOT be similar"


def test_fewer_than_min_common_never_similar():
    """
    If < min_common_challenges=5 common challenges, never flagged as similar.
    Common = challenges where BOTH miners have non-zero scores.
    """
    scores1 = {f"ch_{i}": 0.50 for i in range(4)}  # only 4 challenges
    scores2 = {f"ch_{i}": 0.50 for i in range(4)}  # identical but only 4
    similar, info = are_similar_by_challenges(scores1, scores2)
    assert not similar, (
        f"< min_common=5 challenges should never be flagged as similar. "
        f"Got: {info}"
    )
    assert info["reason"] == "insufficient_common_challenges"


def test_zeros_dont_count_as_common():
    """
    are_similar_by_challenges only counts challenges where BOTH scores > 1e-9.
    A miner that scored 0 on some challenges has fewer common challenges.
    """
    scores1 = {f"ch_{i}": 0.50 for i in range(10)}
    scores2 = {f"ch_{i}": (0.50 if i < 5 else 0.0) for i in range(10)}
    similar, info = are_similar_by_challenges(scores1, scores2)
    # Only 5 common challenges (ch_0..ch_4), at threshold
    # Those 5 are identical -> would be similar IF all within threshold
    assert info["n_common"] == 5, (
        f"Expected 5 common challenges (where both > 0), got {info['n_common']}"
    )


def test_your_scores_sufficiently_different_from_winner():
    """
    Simulate a scenario where you and the current winner have similar
    aggregate scores but your per-challenge distribution differs.

    IMPORTANT: This test should be run against your ACTUAL shard log data.
    The synthetic data here is a placeholder -- replace with real data.

    To use real data:
      1. Read your per-challenge scores from the public R2 shard index
         (field: payload.metrics.acc_breakdown per challenge_id)
      2. Read the winner's per-challenge scores from the same source
      3. Replace my_scores and winner_scores below with real values
    """
    # Synthetic: your model has consistent small advantage on hard clips
    # and disadvantage on easy clips -- creates natural differentiation
    rng = random.Random(42)
    my_scores = {}
    winner_scores = {}
    n_challenges = 20

    for i in range(n_challenges):
        base = 0.40 + rng.random() * 0.30  # challenge difficulty varies
        # Your model: better on hard clips, worse on easy
        my_delta = (0.05 if base < 0.50 else -0.03) + rng.gauss(0, 0.02)
        my_scores[f"challenge_{i}"] = min(1.0, max(0.01, base + my_delta))
        winner_scores[f"challenge_{i}"] = min(1.0, max(0.01, base))

    similar, info = are_similar_by_challenges(my_scores, winner_scores)
    pct_diff = info.get("pct_differentiated", 0)

    print(f"  n_common challenges: {info['n_common']}")
    print(f"  % differentiated:    {pct_diff*100:.1f}%")
    print(f"  flagged as similar:  {similar}")

    # At minimum, 30% of challenges should show meaningful differentiation
    assert pct_diff >= 0.30 or not similar, (
        f"Only {pct_diff*100:.1f}% of challenges differentiated from winner. "
        f"Risk of copy-miner flag if aggregate scores converge. "
        f"Differentiation comes from model quality, not threshold tuning."
    )


def test_tiebreak_means_earlier_commit_block_wins():
    """
    When flagged as similar, the miner with the LOWER first_commit_block wins.
    This means: register early even with a weak model.
    Verify the tiebreak logic is understood.
    """
    # Simulate: you and competitor have identical per-challenge scores
    scores = {f"ch_{i}": 0.45 for i in range(10)}
    similar, _ = are_similar_by_challenges(scores, scores)
    assert similar

    # Tiebreak: lowest commit block wins
    your_commit_block = 7900000
    competitor_commit_block = 7819505  # earlier registration

    winner_block = min(your_commit_block, competitor_commit_block)
    you_win = winner_block == your_commit_block

    assert not you_win, (
        f"Competitor registered at block {competitor_commit_block}, "
        f"you registered at block {your_commit_block}. "
        f"Competitor wins the tiebreak. "
        f"Register early to secure tiebreak advantage."
    )
    print(f"  Your commit block:       {your_commit_block}")
    print(f"  Competitor commit block: {competitor_commit_block}")
    print(f"  Tiebreak winner:         {'you' if you_win else 'competitor'}")


def test_differentiation_requires_model_quality_not_just_threshold():
    """
    Threshold tuning (raising or lowering conf) applies uniformly to all
    challenges -- it shifts your score distribution but doesn't create
    per-challenge differentiation.

    Real differentiation comes from a model that is genuinely better
    on some clip types than the winner (e.g. better on low-light, worse
    on crowded scenes). This is what domain fine-tuning creates.
    """
    # Uniform threshold shift: same delta on every challenge
    winner_scores = {f"ch_{i}": 0.45 + i * 0.01 for i in range(10)}

    # Threshold effect: shift all scores by same amount
    threshold_shifted = {k: v + 0.03 for k, v in winner_scores.items()}
    similar_shifted, info_shifted = are_similar_by_challenges(
        winner_scores, threshold_shifted)

    # All deltas are 0.03, which at score ~0.50 gives threshold=max(0.02, 0.025)=0.025
    # 0.03 > 0.025 -> NOT similar (just barely differentiated)
    # But this is fragile -- a 0.01 shift would be similar
    print(f"  Uniform +0.03 shift: similar={similar_shifted}, "
          f"differentiated={info_shifted['pct_differentiated']*100:.0f}%")

    # Key insight: uniform threshold shift is consistent per-challenge
    # (same delta everywhere) but fragile -- competitor matches it by
    # adjusting their own threshold. Real model differentiation is noisy
    # across challenges (better on hard clips, worse on easy) but robust.
    # Neither should be flagged as similar if delta > threshold.
    assert not similar_shifted, (
        "Uniform +0.03 shift should not be flagged as similar."
    )
    print(f"  Note: uniform shift is consistent but fragile. "
          f"Domain fine-tune creates robust per-clip differentiation.")


if __name__ == "__main__":
    tests = [
        test_identical_scores_are_similar,
        test_large_deltas_are_not_similar,
        test_threshold_is_max_of_abs_and_rel,
        test_fewer_than_min_common_never_similar,
        test_zeros_dont_count_as_common,
        test_your_scores_sufficiently_different_from_winner,
        test_tiebreak_means_earlier_commit_block_wins,
        test_differentiation_requires_model_quality_not_just_threshold,
    ]
    passed, failed = 0, 0
    for test in tests:
        try:
            test()
            print(f"  PASS  {test.__name__}")
            passed += 1
        except AssertionError as e:
            print(f"  FAIL  {test.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"  ERROR {test.__name__}: {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{passed} passed, {failed} failed")
    sys.exit(0 if failed == 0 else 1)
