"""
tests/test_box_validity_and_rtf.py
CHECK 4 + CHECK 7 — Box coordinate validity and RTF

CHECK 4: Degenerate boxes (x1>=x2 or y1>=y2) produce IoU=0 against all GT,
  scoring as FPs. They are the invisible FP source -- no error is raised,
  they just silently inflate your FP count.
  objects.py lines 29-44 (_iou_box)

CHECK 8: Class name case/whitespace normalisation
  objects.py line 47 (_normalize_class_name)

CHECK 7: RTF gate
  rtf.py lines 11-28 (calculate_rtf, check_rtf_gate)
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from fixtures.scoring_helpers import (
    ELEMENTS, iou_box, normalize_class_name, calculate_rtf, rtf_passes,
    score_full_pipeline, parse_miner_prediction,
    Box, PredFrame, GTBox, GTFrame, make_gt_frame, make_pred_frame,
    build_per_image_rows, evaluate_at_threshold,
)


# ── CHECK 4: Box coordinate validity ─────────────────────────────────────────
def test_iou_zero_for_degenerate_box():
    """
    A box where x1 >= x2 or y1 >= y2 has zero area -> IoU=0 with anything.
    This means it can never be a TP -- it always counts as an FP.
    """
    normal_box = (10, 10, 100, 200)

    degenerate_cases = [
        (100, 10, 10, 200),   # x1 > x2
        (10, 200, 100, 10),   # y1 > y2
        (50, 50, 50, 200),    # x1 == x2 (zero width)
        (10, 100, 100, 100),  # y1 == y2 (zero height)
        (50, 50, 50, 50),     # single point
    ]
    for degen in degenerate_cases:
        iou = iou_box(normal_box, degen)
        assert iou == 0.0, (
            f"Degenerate box {degen} should have IoU=0 with any box, "
            f"got {iou:.4f}. This box would always score as a FP."
        )


def test_degenerate_boxes_inflate_fp_count():
    """
    End-to-end: degenerate boxes in miner output inflate FP count
    and reduce fp_score, even when legitimate boxes are also present.
    """
    n_images = 30
    gt_frames = [make_gt_frame(frame_number=i, label="person") for i in range(n_images)]

    # Good predictions only
    pred_good = [make_pred_frame(gf.frame_number, gf) for gf in gt_frames]

    # Same good predictions + 2 degenerate boxes per frame
    pred_with_degen = []
    for gf in gt_frames:
        boxes = [Box(x1=b.x1, y1=b.y1, x2=b.x2, y2=b.y2, cls_id=0, conf=0.9)
                 for b in gf.boxes]
        # Add degenerate boxes
        boxes.append(Box(x1=50, y1=50, x2=50, y2=150, cls_id=0, conf=0.5))  # zero width
        boxes.append(Box(x1=200, y1=100, x2=100, y2=200, cls_id=0, conf=0.5))  # x1>x2
        pred_with_degen.append(PredFrame(frame_id=gf.frame_number, boxes=boxes))

    result_good = score_full_pipeline(
        gt_frames, pred_good, "manak0/Detect-Person")
    result_degen = score_full_pipeline(
        gt_frames, pred_with_degen, "manak0/Detect-Person")

    assert result_degen["fp_score"] < result_good["fp_score"], (
        f"Degenerate boxes should inflate FP count and reduce fp_score. "
        f"Good: {result_good['fp_score']:.4f}, "
        f"With degenerate: {result_degen['fp_score']:.4f}"
    )
    print(f"  fp_score without degen: {result_good['fp_score']:.4f}")
    print(f"  fp_score with degen:    {result_degen['fp_score']:.4f}")
    print(f"  fp_score penalty:       {result_good['fp_score'] - result_degen['fp_score']:.4f}")


def test_all_boxes_are_valid(
    pred_frames=None,
    element_id="manak0/Detect-Person",
    image_width=1280,
    image_height=720,
):
    """
    Run against your actual miner output if pred_frames is provided.
    Otherwise uses synthetic data as a sanity check.
    Verifies: x1<x2, y1<y2, coords>=0, coords<=image bounds.
    """
    if pred_frames is None:
        gt_frames = [make_gt_frame(frame_number=i, label="person")
                     for i in range(5)]
        pred_frames = [make_pred_frame(gf.frame_number, gf)
                       for gf in gt_frames]

    cfg = ELEMENTS[element_id]
    parsed = parse_miner_prediction(pred_frames, cfg["objects"])

    violations = []
    for frame_id, boxes in parsed.items():
        for i, box in enumerate(boxes):
            x1, y1, x2, y2 = box["bbox"]
            if x1 >= x2:
                violations.append(
                    f"frame={frame_id} box={i}: x1={x1} >= x2={x2} (degenerate)")
            if y1 >= y2:
                violations.append(
                    f"frame={frame_id} box={i}: y1={y1} >= y2={y2} (degenerate)")
            if x1 < 0 or y1 < 0:
                violations.append(
                    f"frame={frame_id} box={i}: negative coords ({x1},{y1})")
            if x2 > image_width:
                violations.append(
                    f"frame={frame_id} box={i}: x2={x2} > image_width={image_width}")
            if y2 > image_height:
                violations.append(
                    f"frame={frame_id} box={i}: y2={y2} > image_height={image_height}")

    assert len(violations) == 0, (
        f"Found {len(violations)} invalid boxes:\n" +
        "\n".join(f"  {v}" for v in violations[:10]) +
        ("\n  ..." if len(violations) > 10 else "")
    )


def test_tiny_boxes_count_as_fp():
    """
    Very small boxes (area < ~100 px^2) are typically noise detections.
    They will never IoU >= 0.5 with any reasonable GT box.
    Verify they score as FPs and consider filtering in miner.py.
    """
    # Tiny box 5x5
    tiny = (50, 50, 55, 55)  # area = 25 px^2
    normal_gt = (40, 40, 120, 180)  # large GT box

    iou = iou_box(tiny, normal_gt)
    assert iou < 0.5, (
        f"Tiny box should have IoU < 0.5 with GT, got {iou:.4f}. "
        "This box can never be a TP -- it will count as a FP."
    )
    print(f"  Tiny box (5x5) IoU with normal GT box: {iou:.6f}")
    print(f"  Recommendation: filter boxes with area < 400 px^2 in miner.py")


# ── CHECK 8: Class name normalisation ─────────────────────────────────────────
def test_class_name_normalisation():
    """
    _normalize_class_name strips and lowercases. Both GT and pred go through this.
    Verify your label and the GT label produce the same normalised string.
    """
    cases = [
        ("person",   "person"),
        ("Person",   "person"),
        ("PERSON",   "person"),
        (" person ", "person"),
        ("vehicle",  "vehicle"),
        ("Vehicle",  "vehicle"),
        ("VEHICLE",  "vehicle"),
        (" vehicle ", "vehicle"),
    ]
    for raw, expected in cases:
        result = normalize_class_name(raw)
        assert result == expected, (
            f"normalize_class_name('{raw}') = '{result}', expected '{expected}'"
        )


def test_case_mismatch_causes_zero_map50():
    """
    If miner outputs "Person" (capital P) but GT has "person",
    they normalise to the same string -> no problem.
    But if element.objects contains "Person" and GT has "person",
    the class_name in per_image rows will differ -> zero AP.
    """
    # Simulate: miner outputs cls_id=0, objects=["Person"] (capital P)
    # GT label is "person" (lowercase)
    # Both go through _normalize_class_name -> both become "person" -> match
    pred_label = normalize_class_name("Person")
    gt_label   = normalize_class_name("person")
    assert pred_label == gt_label, (
        f"After normalisation: pred='{pred_label}', gt='{gt_label}'. "
        "These should match."
    )

    # Verify in full pipeline: objects=["Person"] still works
    gt_frames = [make_gt_frame(frame_number=i, label="person") for i in range(5)]
    pred_frames = [
        PredFrame(
            frame_id=gf.frame_number,
            boxes=[Box(x1=b.x1, y1=b.y1, x2=b.x2, y2=b.y2, cls_id=0, conf=0.9)
                   for b in gf.boxes]
        )
        for gf in gt_frames
    ]
    # Use capitalized objects list
    from fixtures.scoring_helpers import build_per_image_rows, evaluate_at_threshold
    parsed = parse_miner_prediction(pred_frames, ["Person"])
    rows = build_per_image_rows(gt_frames, parsed)
    metrics = evaluate_at_threshold(rows)

    assert metrics["map50"] > 0.5, (
        f"Case mismatch in objects list should be handled by normalisation. "
        f"map50={metrics['map50']:.4f} -- check normalisation is working."
    )


# ── CHECK 7: RTF gate ─────────────────────────────────────────────────────────
def test_rtf_formula():
    """
    RTF = (p95_ms / 10000) * (service_rate_fps / 5)
    Both elements: service_rate_fps=5, budget=10000ms -> RTF = p95_ms/10000
    """
    cases = [
        (5000, 5, 0.5, True),    # 5s p95, 5fps -> RTF=0.5 PASS
        (8500, 5, 0.85, True),   # 8.5s p95 -> RTF=0.85 PASS (safe target)
        (10000, 5, 1.0, True),   # exactly at limit PASS
        (10001, 5, 1.0001, False), # 1ms over -> FAIL
        (12000, 5, 1.2, False),  # 12s p95 -> RTF=1.2 FAIL
        (5000, 10, 1.0, True),   # higher fps at same latency
        (5001, 10, 1.0002, False), # higher fps just over
    ]
    for p95, fps, expected_rtf, expected_pass in cases:
        rtf = calculate_rtf(p95, fps)
        passes = rtf_passes(p95, fps)
        assert abs(rtf - expected_rtf) < 1e-4, (
            f"p95={p95}ms, fps={fps}: RTF={rtf:.4f}, expected {expected_rtf:.4f}"
        )
        assert passes == expected_pass, (
            f"p95={p95}ms, fps={fps}: RTF={rtf:.4f} -> "
            f"pass={passes}, expected {expected_pass}"
        )


def test_rtf_safe_headroom():
    """
    Verify your target p95 provides 15% safety margin below the RTF gate.
    At service_rate_fps=5: gate is 10000ms, safe target is 8500ms.
    """
    service_rate_fps = 5
    gate_budget = 10000.0
    safe_target = gate_budget * 0.85  # 8500ms

    rtf_at_safe = calculate_rtf(safe_target, service_rate_fps)
    rtf_at_gate = calculate_rtf(gate_budget, service_rate_fps)

    assert rtf_at_safe <= 0.85, (
        f"Safe target {safe_target}ms gives RTF={rtf_at_safe:.4f}, "
        "expected <= 0.85"
    )
    assert rtf_at_gate == 1.0, (
        f"Gate budget {gate_budget}ms gives RTF={rtf_at_gate:.4f}, expected 1.0"
    )
    print(f"  RTF at 8500ms (safe target): {rtf_at_safe:.3f}")
    print(f"  RTF at 10000ms (gate):       {rtf_at_gate:.3f}")
    print(f"  RTF at 12000ms (fail):       {calculate_rtf(12000, 5):.3f}")


def test_rtf_score_forced_to_zero():
    """
    When RTF > 1.0, evaluate.py forces final_score = 0.0 regardless
    of detection quality. Verify this is understood.
    """
    # This is the exact logic from evaluate.py line 274-279
    def evaluate_with_rtf(detection_score, p95_ms, fps=5):
        rtf = calculate_rtf(p95_ms, fps)
        if rtf > 1.0:
            return 0.0  # forced to zero
        return detection_score

    # Perfect detection but slow -> zero score
    assert evaluate_with_rtf(0.80, 12000) == 0.0, (
        "RTF > 1.0 should force score to 0.0 even with good detection."
    )
    # Good detection and fast -> kept
    assert evaluate_with_rtf(0.80, 8000) == 0.80, (
        "RTF <= 1.0 should preserve the detection score."
    )


if __name__ == "__main__":
    tests = [
        test_iou_zero_for_degenerate_box,
        test_degenerate_boxes_inflate_fp_count,
        test_all_boxes_are_valid,
        test_tiny_boxes_count_as_fp,
        test_class_name_normalisation,
        test_case_mismatch_causes_zero_map50,
        test_rtf_formula,
        test_rtf_safe_headroom,
        test_rtf_score_forced_to_zero,
    ]
    passed, failed = 0, 0
    for test in tests:
        try:
            test()
            print(f"  PASS  {test.__name__}")
            passed += 1
        except AssertionError as e:
            print(f"  FAIL  {test.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"  ERROR {test.__name__}: {e}")
            failed += 1
    print(f"\n{passed} passed, {failed} failed")
    sys.exit(0 if failed == 0 else 1)
