# SN44 Scoring Alignment Plan
# Elements: manak0/Detect-Person, manak0/Detect-detect-vehicle
# Manifest block: 7819505

## SCOPE CONSTRAINT
Only the following scoring code is relevant for these two elements.
Do NOT touch, test, or reference PlayerDetect, smoothness, iou, count,
precision, recall, or keypoints code paths. They are NOT in either manifest.

## ACTIVE SCORING CODE (the only paths that affect emissions)

### Path 1 — parse_miner_prediction()
File: scorevision/utils/evaluate.py lines 88-144
What it does:
  - Reads miner output frames from SVRunOutput.predictions["frames"]
  - For each box: converts cls_id (int) -> object_names[cls_id] (str)
  - SILENTLY DROPS any box where cls_id is out of range or non-integer
  - Reads confidence from bbox.get("score", bbox.get("conf"))
  - Builds dict[frame_number -> {bboxes, action, keypoints}]
Critical failure: if cls_id does not map to element.objects correctly,
every detection is dropped and map50 = 0.0

### Path 2 — _build_per_image_rows()
File: scorevision/vlm_pipeline/non_vlm_scoring/objects.py lines 87-124
What it does:
  - Joins miner output to pseudo-GT by frame_number (exact integer match)
  - If miner has no entry for a GT frame: that frame contributes 0 TPs
  - SILENTLY uses empty predictions for missing frame_numbers
Critical failure: if your frame_id values don't exactly match the
frame_numbers sent in the challenge, all frames score as missed detections

### Path 3 — _evaluate_detection_metrics_at_threshold(iou=0.5)
File: scorevision/vlm_pipeline/non_vlm_scoring/objects.py lines 127-248
What it does:
  - Groups predictions by class_name (lowercased, stripped)
  - Sorts predictions by score DESCENDING (confidence ranking matters)
  - For each pred: finds best IoU match in GT, marks as TP if IoU >= 0.5
  - Computes per-class AP via interpolated precision-recall curve
  - Computes global_FP across ALL classes, ALL images
  - map50 = mean(per_class_AP) -- only classes with GT count
  - ffpi = global_FP / n_images; false_positive = max(0, 1 - ffpi/10)
Critical failures:
  a) Class name mismatch (pred says "Person", GT says "person") -> 0 TPs
  b) Degenerate boxes (x1>=x2 or y1>=y2) -> IoU=0, counts as FP
  c) Missing score field -> defaults to 1.0 for ALL boxes -> AP curve flat
  d) Predictions on frames not in GT -> all count as FPs

### Path 4 — weight_score()
File: scorevision/utils/manifest.py lines 356-358
Formula: beta * max(max(total_weighted - baseline_theta, 0), delta_floor)
  total_weighted = map50 * pillar_weight_map50 + fp * pillar_weight_fp

Detect-Person:  total = map50*0.65 + fp*0.35, theta=0.3755, delta=0.01, beta=1
Detect-Vehicle: total = map50*0.60 + fp*0.40, theta=0.4072, delta=0.01, beta=1


## ALIGNMENT CHECKS (ordered by impact)

### CHECK 1 — Class mapping [PRIORITY: CRITICAL]
Status: TODO
Test file: tests/test_class_mapping.py
Verify:
  - element.objects for Detect-Person = ["person"] (or equivalent)
  - element.objects for Detect-Vehicle = ["vehicle"] (or equivalent)
  - Your model outputs cls_id=0 for the target class
  - parse_miner_prediction() with your output produces non-empty bboxes
  - The label on each BoundingBox matches element.objects[cls_id] exactly
  - _normalize_class_name(your_label) == _normalize_class_name(gt_label)
Fix if failing: update cls_id in model output or remap in miner.py postprocess

### CHECK 2 — Frame number alignment [PRIORITY: CRITICAL]
Status: TODO
Test file: tests/test_frame_alignment.py
Verify:
  - Your miner returns frame_id values that exactly match input frame IDs
  - No off-by-one errors (challenge sends frame_id=5, you return frame_id=5)
  - No frame_id=-1 (default fallback in parse_miner_prediction line 99)
  - _build_per_image_rows() produces n_rows == n_gt_frames (no missing frames)
Fix if failing: ensure predict_batch offset arithmetic is correct in miner.py

### CHECK 3 — Confidence score validity [PRIORITY: HIGH]
Status: TODO
Test file: tests/test_confidence_scores.py
Verify:
  - Every box has a non-None score (float in [0.0, 1.0])
  - Scores are not all identical (would flatten AP curve to single point)
  - Scores are not all 0.0 or all 1.0
  - Higher-confidence boxes have better average IoU with GT than lower ones
  - The key: "score" field is present (validator reads bbox.get("score",
    bbox.get("conf")) -- confirm your output uses one of these keys)
Fix if failing: ensure conf is passed through in miner.py BoundingBox output

### CHECK 4 — Box coordinate validity [PRIORITY: HIGH]
Status: TODO
Test file: tests/test_box_validity.py
Verify:
  - All boxes: x1 < x2 and y1 < y2 (non-degenerate)
  - All coordinates >= 0
  - All coordinates <= image dimensions (1280px default resize_long)
  - No NaN or Inf values in coordinates
  - Boxes with area < 100 px^2 are filtered (likely noise, count as FPs)
Fix if failing: add coordinate clamp/filter in miner.py postprocess

### CHECK 5 — False positive count at current threshold [PRIORITY: HIGH]
Status: TODO
Test file: tests/test_fp_budget.py
Verify using replay buffer frames:
  - Run model at current conf threshold on 30 images
  - Compute ffpi = global_FP / 30
  - Compute fp_score = max(0, 1 - ffpi/10)
  - Verify fp_score >= 0.75 (below this, total_w likely below theta)
  - Compute total_weighted and verify > baseline_theta for your element
  - Sweep conf in [0.30, 0.35, 0.40, 0.45, 0.50, 0.55] and report
    total_weighted at each -- identify empirical optimum
Fix if failing: adjust conf threshold; add box area/aspect ratio filters

### CHECK 6 — Score vs gate computation [PRIORITY: MEDIUM]
Status: TODO
Test file: tests/test_gate_computation.py
Verify:
  - weight_score() formula is correctly reproduced locally
  - Given observed map50 and fp_score, compute expected gated score
  - Verify the result matches what appears in shard acc_breakdown
  - Check you are above baseline_theta (otherwise earning delta_floor only)
  - For Detect-Person: confirm 0.65*map50 + 0.35*fp > 0.3755
  - For Detect-Vehicle: confirm 0.60*map50 + 0.40*fp > 0.4072

### CHECK 7 — RTF local measurement [PRIORITY: MEDIUM]
Status: TODO
Test file: tests/test_rtf.py
Verify:
  - Instrument predict_batch() with wall-clock timing
  - Compute p95 over 50 calls on realistic image batches
  - Verify RTF = (p95_ms / 10000) * (service_rate_fps / 5) <= 0.85
  - service_rate_fps = 5 for both elements (budget = 10,000ms p95)
Fix if failing: ONNX conversion, batch size tuning, input resolution

### CHECK 8 — Class name case/whitespace normalisation [PRIORITY: LOW]
Status: TODO
Test file: tests/test_class_normalisation.py
Verify:
  - _normalize_class_name strips whitespace and lowercases
  - "Person", " person ", "PERSON" all normalise to "person"
  - Your miner output uses exactly the string from element.objects
    (no trailing spaces, no capitalisation differences)
  - GT class names from SAM3 also normalise to the same string
Fix if failing: lowercase and strip in miner.py label assignment


## COMPLETION CONDITION
All 8 checks passing with green tests.
Progress file shows verified status for each check.
All tests committed to miner/tests/.
