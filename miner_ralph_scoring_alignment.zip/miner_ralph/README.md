# SN44 Scoring Alignment Ralph Loop

Automated verification that your miner's output is correctly aligned with
the validator's scoring functions for **Detect-Person** and
**Detect-detect-vehicle** on Bittensor Subnet 44.

## Scope

Only the active scoring paths for these two elements:

| Element | Active pillars | Scoring code |
|---|---|---|
| `manak0/Detect-Person` | `map50` (0.65) + `false_positive` (0.35) | `evaluate.py`, `objects.py` |
| `manak0/Detect-detect-vehicle` | `map50` (0.60) + `false_positive` (0.40) | same |

Pillars registered but **not** in either manifest — not tested here:
`iou`, `count`, `precision`, `recall`, `smoothness`, `keypoints`, `palette`, `role`.

## Structure

```
miner_ralph/
├── plan.md                          # all 8 checks, ordered by impact
├── progress.txt                     # append-only session log
├── run_all_tests.py                 # master runner
├── scoring_alignment_ralph.sh       # Ralph loop for Claude Code
├── fixtures/
│   └── scoring_helpers.py           # exact replicas of validator functions
└── tests/
    ├── test_class_mapping.py        # CHECK 1 (CRITICAL)
    ├── test_frame_alignment.py      # CHECK 2 (CRITICAL)
    ├── test_confidence_and_gate.py  # CHECK 3 + 5 + 6 (HIGH)
    ├── test_box_validity_and_rtf.py # CHECK 4 + 7 + 8 (HIGH)
    └── test_copy_miner_differentiation.py  # CHECK 5 (MEDIUM)
```

## Quick Start

```bash
# Run all checks
python run_all_tests.py

# Run one check
python run_all_tests.py --check 1

# Run with full output
python run_all_tests.py --verbose

# Run and update progress.txt
python run_all_tests.py --update-progress
```

## The Ralph Loop

```bash
chmod +x scoring_alignment_ralph.sh

# Point to your repos first (edit the script):
# SCORING_REPO="../turbovision"
# MINER_REPO="../miner"

./scoring_alignment_ralph.sh 8    # run up to 8 iterations
```

Each iteration:
1. Reads `plan.md` and `progress.txt` to find the next TODO check
2. Reads the relevant validator source file to understand the exact code
3. Runs the test file and captures output
4. If tests fail: diagnoses the cause, fixes `miner.py`, re-runs
5. Commits the fix and appends to `progress.txt`
6. Outputs `<promise>COMPLETE</promise>` when all 8 checks pass

## The 8 Checks

| # | Priority | What it catches |
|---|---|---|
| 1 | CRITICAL | `cls_id` not mapped to `element.objects` → all detections silently dropped, `map50=0` |
| 2 | CRITICAL | `frame_id` mismatch → all GT frames treated as missed, `map50` collapses |
| 3 | HIGH | Missing/invalid confidence scores → AP curve degenerates to single point |
| 4 | HIGH | Degenerate boxes (`x1>=x2`) → invisible FPs inflating false positive count |
| 5 | HIGH | FP count at current threshold → `fp_score` too low to cross `baseline_theta` |
| 6 | HIGH | `weight_score()` formula → verify your gated score matches shard log |
| 7 | HIGH | RTF > 1.0 → score forced to 0 regardless of detection quality |
| 8 | MEDIUM | Class name case/whitespace → `"Person"` vs `"person"` mismatch |
| 5 | MEDIUM | Copy-miner similarity → flagged if per-challenge scores within `delta_abs=0.02` of winner |

## The Two Most Common Silent Failures

**Check 1 (class mapping)** is the most impactful. If your model outputs
`cls_id=0` but `element.objects` is wrong, `parse_miner_prediction()` in
`evaluate.py` line 110-113 silently drops every detection. You get
`map50=0.0` with no error, no warning, and no indication in the logs.

**Check 2 (frame alignment)** is equally silent. If your `frame_id` values
don't match the challenge's `frame_number` values exactly,
`_build_per_image_rows()` in `objects.py` line 93 produces empty predictions
for every unmatched GT frame. A one-frame overlap (e.g. both include
`frame_id=0`) produces `map50 ≈ 1/n_frames` instead of 0 — making
partial offset bugs harder to detect than complete misses.

## Scoring Formulas (live manifest, block 7819505)

**Detect-Person:**
```
total_weighted     = map50 * 0.65 + fp_score * 0.35
improvement        = max(max(total_weighted - 0.3755, 0), 0.01)
gated_score        = 1.0 * improvement
```

**Detect-Vehicle:**
```
total_weighted     = map50 * 0.60 + fp_score * 0.40
improvement        = max(max(total_weighted - 0.4072, 0), 0.01)
gated_score        = 1.0 * improvement
```

**false_positive:**
```
ffpi      = global_FP / n_images   (n_images=30 for both elements)
fp_score  = max(0, 1 - ffpi / 10)
```
Target `fp_score=0.85` means ≤1.5 FPs per image (45 total across 30 images).

**RTF gate** (both elements, `service_rate_fps=5`):
```
RTF = (p95_latency_ms / 10000) * (service_rate_fps / 5)
    = p95_latency_ms / 10000        (at fps=5)
Must be <= 1.0 or score = 0
Safe target: p95 <= 8500ms
```

## Connecting to Real Miner Output

`test_all_boxes_are_valid()` in `test_box_validity_and_rtf.py` and
`test_your_scores_sufficiently_different_from_winner()` in
`test_copy_miner_differentiation.py` accept real miner output as arguments.

To test against your actual model:

```python
# In your test script:
from miner.miner import Miner
from pathlib import Path
import numpy as np

miner = Miner(Path("path/to/your/hf_repo"))
batch = [np.zeros((720, 1280, 3), dtype=np.uint8) for _ in range(10)]
results = miner.predict_batch(batch, offset=0, n_keypoints=0)

# Convert TVFrameResult -> PredFrame for the test helpers
from fixtures.scoring_helpers import Box, PredFrame
pred_frames = [
    PredFrame(
        frame_id=r.frame_id,
        boxes=[Box(x1=b.x1, y1=b.y1, x2=b.x2, y2=b.y2,
                   cls_id=b.cls_id, conf=b.conf)
               for b in r.boxes]
    )
    for r in results
]

# Now run:
from tests.test_box_validity_and_rtf import test_all_boxes_are_valid
test_all_boxes_are_valid(pred_frames=pred_frames)
```

## After All Checks Pass

1. Deploy to Chutes: `sv push --model-path <path> --element-id <element_id>`
2. Wait 3 windows for EWMA to stabilise
3. Compare shard log `acc_breakdown` values against local predictions
4. If they match: scoring alignment verified end-to-end
5. If they differ by > 0.05: check for pseudo-GT noise (expected ±0.04 σ)
   or manifest change (new `pgt_recipe_hash`)
